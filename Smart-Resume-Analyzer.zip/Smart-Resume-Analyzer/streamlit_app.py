import streamlit as st
import re
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from utils.text_extractor import extract_text
from utils.text_preprocessor import preprocess_text, remove_stopwords
from utils.tfidf_vectorizer import compute_tf, compute_idf, compute_tfidf
from utils.similarity import cosine_similarity

# ---------------- DARK MODE ----------------
dark_mode = st.toggle("🌙 Dark Mode")

if dark_mode:
    st.markdown(
        """
        <style>
        body { background-color: #0e1117; color: white; }
        </style>
        """,
        unsafe_allow_html=True
    )

# ---------------- SKILLS ----------------
skills_list = [
    "python", "java", "react", "sql",
    "machine learning", "data structures",
    "system design", "aws", "firebase",
    "mongodb", "nodejs"
]

action_verbs = [
    "developed", "implemented", "designed",
    "built", "optimized", "created",
    "engineered", "improved"
]

# ---------------- FUNCTIONS ----------------
def extract_skills(text):
    return [skill for skill in skills_list if skill in text.lower()]

def detect_weak_words(text):
    weak_words = ["learned", "worked on", "done", "made"]
    return [w for w in weak_words if w in text.lower()]

def check_numbers(text):
    return len(re.findall(r"\d+", text))

def analyze_bullets(text):
    lines = text.split("\n")
    results = []

    for line in lines:
        line = line.strip()
        if len(line) < 20:
            continue

        issues = []

        if not any(v in line.lower() for v in action_verbs):
            issues.append("Use action verb")

        if not re.search(r"\d+", line):
            issues.append("Add numbers")

        if any(w in line.lower() for w in ["worked on", "made", "done"]):
            issues.append("Avoid weak words")

        results.append((line, issues if issues else ["Strong"]))

    return results

def generate_pdf(score, match, missing):
    doc = SimpleDocTemplate("resume_report.pdf")
    styles = getSampleStyleSheet()
    content = []

    content.append(Paragraph(f"ATS Score: {score}%", styles["Title"]))
    content.append(Spacer(1, 10))

    content.append(Paragraph(f"Matching Skills: {', '.join(match)}", styles["Normal"]))
    content.append(Paragraph(f"Missing Skills: {', '.join(missing)}", styles["Normal"]))

    doc.build(content)
    return "resume_report.pdf"

# ---------------- UI ----------------
st.title("💀 Ultimate Resume Analyzer")

resume_file = st.file_uploader("Upload Resume", type=["pdf", "txt"])
jd_text = st.text_area("Paste Job Description")

if st.button("🚀 Analyze"):

    if resume_file and jd_text:

        resume_text = extract_text(resume_file)
        resume_clean = remove_stopwords(preprocess_text(resume_text))
        jd_clean = remove_stopwords(preprocess_text(jd_text))

        resume_skills = set(extract_skills(resume_clean))
        jd_skills = set(extract_skills(jd_clean))

        match = resume_skills & jd_skills
        missing = jd_skills - resume_skills

        # ATS SCORE
        docs = [resume_clean, jd_clean]
        tf1 = compute_tf(resume_clean)
        tf2 = compute_tf(jd_clean)
        idf = compute_idf(docs)

        tfidf1 = compute_tfidf(tf1, idf)
        tfidf2 = compute_tfidf(tf2, idf)

        cosine_score = cosine_similarity(tfidf1, tfidf2)
        skill_score = len(match) / len(jd_skills) if jd_skills else 0

        final_score = (0.6 * skill_score) + (0.4 * cosine_score)
        score_percent = round(final_score * 100, 2)

        st.subheader(f"🎯 ATS Score: {score_percent}%")

        # SCORE BREAKDOWN
        st.subheader("📊 Score Breakdown")
        st.write(f"Skill Match: {round(skill_score * 100, 2)}%")
        st.write(f"Content Similarity: {round(cosine_score * 100, 2)}%")

        # SKILLS
        st.subheader("✅ Matching Skills")
        st.write(match)

        st.subheader("❌ Missing Skills")
        st.write(missing)

        # BULLET ANALYSIS
        st.subheader("📍 Bullet Analysis")
        bullets = analyze_bullets(resume_text)

        for line, issues in bullets:
            st.write(f"👉 {line}")
            for issue in issues:
                if issue == "Strong":
                    st.success(issue)
                else:
                    st.warning(issue)

        # AI SUGGESTIONS
        st.subheader("🤖 Smart Suggestions")

        if missing:
            for m in missing:
                st.info(f"Add skill: {m}")

        if detect_weak_words(resume_text):
            st.info("Replace weak words with action verbs")

        if check_numbers(resume_text) < 5:
            st.info("Add measurable achievements")

        # PDF DOWNLOAD
        if st.button("📄 Download Report"):
            file_path = generate_pdf(score_percent, match, missing)
            with open(file_path, "rb") as f:
                st.download_button("Download PDF", f, file_name="report.pdf")

    else:
        st.warning("Upload resume and job description")