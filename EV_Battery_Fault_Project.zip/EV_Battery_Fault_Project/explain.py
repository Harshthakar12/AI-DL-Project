"""
=============================================================================
Project: Explainable EV Battery Fault Prediction Using ML, NLP and LLM
File: explain.py
Description: Explainability module that computes parameter importance for
             individual battery predictions (local explainability) using
             feature attributions and SHAP (if available).
=============================================================================
"""

import numpy as np
import pandas as pd

# Safe import for SHAP in case it is installed or not
try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False


def explain_prediction(model, input_dict, feature_names=None):
    """
    Computes local feature importance for an individual battery input.

    Parameters:
        model: Trained RandomForestClassifier object
        input_dict (dict): Dictionary with keys:
                           {'Voltage': float, 'Current': float, 'Temperature': float,
                            'SOC': float, 'SOH': float}
        feature_names (list): List of feature names in training order

    Returns:
        dict: Contains prediction, fault_probability, sorted feature attributions,
              and explanation text summary.
    """
    if feature_names is None:
        feature_names = ['Voltage', 'Current', 'Temperature', 'SOC', 'SOH']

    # Convert single user input dictionary to a 1-row DataFrame
    input_df = pd.DataFrame([input_dict])[feature_names]

    # Model prediction and probabilities
    prediction = int(model.predict(input_df)[0])
    probabilities = model.predict_proba(input_df)[0]
    fault_prob = float(probabilities[1])  # Probability of Fault (class 1)
    normal_prob = float(probabilities[0]) # Probability of Normal (class 0)

    # Typical normal reference baselines (from healthy operating parameters)
    baseline_normal = {
        'Voltage': 3.70,     # Nominal cell voltage (V)
        'Current': 25.0,     # Normal operating current (A)
        'Temperature': 28.0, # Normal operating temperature (°C)
        'SOC': 65.0,         # Normal mid-range state of charge (%)
        'SOH': 92.0          # Healthy state of health (%)
    }

    raw_scores = {}
    shap_used = False

    # Attempt SHAP TreeExplainer if SHAP package is installed
    if SHAP_AVAILABLE:
        try:
            explainer = shap.TreeExplainer(model)
            shap_values = explainer.shap_values(input_df)
            
            # For binary classification, shap_values can be a list [class0, class1]
            # or a 3D array (samples, features, classes)
            if isinstance(shap_values, list) and len(shap_values) == 2:
                # Contribution towards class 1 (Fault)
                vals = shap_values[1][0]
            elif hasattr(shap_values, 'shape') and len(shap_values.shape) == 3:
                vals = shap_values[0, :, 1]
            else:
                vals = shap_values[0]

            for i, feat in enumerate(feature_names):
                # Positive SHAP pushes towards Fault; magnitude indicates influence
                raw_scores[feat] = max(0.0, float(vals[i]))
            shap_used = True
        except Exception:
            shap_used = False

    # If SHAP is not used or returned all zeros, use Model Marginal Attribution:
    # Measure how much the fault probability drops when feature is reset to normal baseline
    if not shap_used or sum(raw_scores.values()) <= 1e-6:
        for feat in feature_names:
            perturbed = input_df.copy()
            perturbed[feat] = baseline_normal[feat]
            perturbed_fault_prob = float(model.predict_proba(perturbed)[0][1])
            
            # Sensitivity: impact of this parameter deviating from normal
            # If fault_prob > 0.5, impact is how much replacing it with normal reduces fault probability
            if prediction == 1:
                diff = max(0.0, fault_prob - perturbed_fault_prob)
            else:
                diff = max(0.0, perturbed_fault_prob - fault_prob)
            
            # Combine with global tree importance weighting
            global_imp = model.feature_importances_[feature_names.index(feat)]
            raw_scores[feat] = diff * 0.7 + global_imp * 0.3

    # Normalize scores so they sum to 100% for clear visualization
    total_score = sum(raw_scores.values())
    if total_score > 0:
        normalized_scores = {k: v / total_score for k, v in raw_scores.items()}
    else:
        # Fallback to model's global feature importances
        normalized_scores = {
            f: float(imp) for f, imp in zip(feature_names, model.feature_importances_)
        }

    # Sort features from highest to lowest influence
    sorted_features = sorted(normalized_scores.items(), key=lambda x: x[1], reverse=True)

    # Classify influence levels (High, Medium, Low)
    ranked_factors = []
    for rank, (feat, score) in enumerate(sorted_features):
        percentage = score * 100
        if percentage >= 28.0 or rank == 0:
            level = "High influence"
        elif percentage >= 15.0:
            level = "Medium influence"
        else:
            level = "Low influence"

        ranked_factors.append({
            'feature': feat,
            'value': input_dict[feat],
            'importance_score': round(float(score), 4),
            'importance_percent': round(percentage, 1),
            'influence_level': level
        })

    return {
        'prediction': prediction,
        'prediction_label': 'Faulty' if prediction == 1 else 'Normal',
        'fault_probability': round(fault_prob, 4),
        'normal_probability': round(normal_prob, 4),
        'shap_used': shap_used,
        'ranked_factors': ranked_factors
    }


if __name__ == '__main__':
    # Quick standalone test
    print("Testing explainability module...")
    # Demo dummy model placeholder test
    test_sample = {
        'Voltage': 3.15,
        'Current': 80.0,
        'Temperature': 55.0,
        'SOC': 92.0,
        'SOH': 68.0
    }
    print(f"Sample Input: {test_sample}")
    print(f"SHAP available: {SHAP_AVAILABLE}")
