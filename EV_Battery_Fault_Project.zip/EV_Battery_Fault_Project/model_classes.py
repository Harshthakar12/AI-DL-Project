"""
=============================================================================
Project: Explainable EV Battery Fault Prediction Using ML, NLP and LLM
File: model_classes.py
Description: Defines the Decision Tree and Random Forest Classifier classes
             used for training and prediction fallback.
=============================================================================
"""

import numpy as np

class DecisionTreeNode:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None, prob=None):
        self.feature = feature
        self.threshold = threshold
        self.left = left
        self.right = right
        self.value = value
        self.prob = prob

class SimpleDecisionTree:
    def __init__(self, max_depth=6, min_samples_split=5, max_features='sqrt'):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.root = None
        self.feature_importances_ = None

    def _gini(self, y):
        if len(y) == 0:
            return 0
        p1 = np.mean(y == 1)
        p0 = 1 - p1
        return 1 - (p0**2 + p1**2)

    def _best_split(self, X, y, n_features):
        best_gain = -1
        split_idx, split_thresh = None, None
        n_samples, total_features = X.shape
        
        feat_indices = np.random.choice(total_features, n_features, replace=False)
        current_gini = self._gini(y)

        for f_idx in feat_indices:
            thresholds = np.percentile(X[:, f_idx], [20, 40, 50, 60, 80])
            for thresh in thresholds:
                left_mask = X[:, f_idx] <= thresh
                right_mask = ~left_mask
                if np.sum(left_mask) == 0 or np.sum(right_mask) == 0:
                    continue

                w_left = np.sum(left_mask) / n_samples
                w_right = 1 - w_left
                gini_left = self._gini(y[left_mask])
                gini_right = self._gini(y[right_mask])
                gain = current_gini - (w_left * gini_left + w_right * gini_right)

                if gain > best_gain:
                    best_gain = gain
                    split_idx = f_idx
                    split_thresh = thresh

        return split_idx, split_thresh, best_gain

    def _build_tree(self, X, y, depth=0):
        n_samples, n_features = X.shape
        num_labels = len(np.unique(y))

        prob = np.mean(y == 1) if len(y) > 0 else 0.5
        val = 1 if prob >= 0.5 else 0

        if depth >= self.max_depth or num_labels <= 1 or n_samples < self.min_samples_split:
            return DecisionTreeNode(value=val, prob=prob)

        n_sub_feat = max(1, int(np.sqrt(n_features)))
        split_idx, split_thresh, gain = self._best_split(X, y, n_sub_feat)

        if split_idx is None or gain <= 1e-5:
            return DecisionTreeNode(value=val, prob=prob)

        left_mask = X[:, split_idx] <= split_thresh
        right_mask = ~left_mask

        left_child = self._build_tree(X[left_mask], y[left_mask], depth + 1)
        right_child = self._build_tree(X[right_mask], y[right_mask], depth + 1)
        return DecisionTreeNode(feature=split_idx, threshold=split_thresh, left=left_child, right=right_child, prob=prob)

    def fit(self, X, y):
        X = np.array(X)
        y = np.array(y)
        self.root = self._build_tree(X, y)

    def _predict_row(self, node, x):
        if node.feature is None:
            return node.value
        if x[node.feature] <= node.threshold:
            return self._predict_row(node.left, x)
        return self._predict_row(node.right, x)

    def _predict_row_prob(self, node, x):
        if node.feature is None:
            return node.prob
        if x[node.feature] <= node.threshold:
            return self._predict_row_prob(node.left, x)
        return self._predict_row_prob(node.right, x)

    def predict(self, X):
        X = np.array(X)
        return np.array([self._predict_row(self.root, x) for x in X])

    def predict_proba(self, X):
        X = np.array(X)
        p1 = np.array([self._predict_row_prob(self.root, x) for x in X])
        p0 = 1.0 - p1
        return np.column_stack([p0, p1])


class SimpleRandomForestClassifier:
    """Ensemble Random Forest Classifier that mirrors Scikit-Learn's interface."""
    def __init__(self, n_estimators=50, max_depth=6, random_state=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.random_state = random_state
        self.trees = []
        self.feature_importances_ = None

    def fit(self, X, y):
        np.random.seed(self.random_state)
        X_mat = np.array(X)
        y_vec = np.array(y)
        n_samples, n_features = X_mat.shape
        self.trees = []

        for _ in range(self.n_estimators):
            boot_idx = np.random.choice(n_samples, n_samples, replace=True)
            X_b, y_b = X_mat[boot_idx], y_vec[boot_idx]
            tree = SimpleDecisionTree(max_depth=self.max_depth)
            tree.fit(X_b, y_b)
            self.trees.append(tree)

        # Approximate feature importances by parameter sensitivity
        importances = np.zeros(n_features)
        base_probs = self.predict_proba(X_mat)[:, 1]
        for f in range(n_features):
            X_perturbed = X_mat.copy()
            X_perturbed[:, f] = np.mean(X_mat[:, f])
            pert_probs = self.predict_proba(X_perturbed)[:, 1]
            importances[f] = np.mean(np.abs(base_probs - pert_probs))
        
        total = np.sum(importances)
        if total > 0:
            self.feature_importances_ = importances / total
        else:
            self.feature_importances_ = np.ones(n_features) / n_features

    def predict_proba(self, X):
        X = np.array(X)
        all_probs = [tree.predict_proba(X)[:, 1] for tree in self.trees]
        avg_p1 = np.mean(all_probs, axis=0)
        avg_p0 = 1.0 - avg_p1
        return np.column_stack([avg_p0, avg_p1])

    def predict(self, X):
        probs = self.predict_proba(X)
        return (probs[:, 1] >= 0.5).astype(int)
