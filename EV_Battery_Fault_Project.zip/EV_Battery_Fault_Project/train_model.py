"""
=============================================================================
Project: Explainable EV Battery Fault Prediction Using ML, NLP and LLM
File: train_model.py
Description: Trains a Random Forest Classifier on EV battery telemetry,
             calculates real evaluation metrics, and saves the trained model.
             Uses Scikit-Learn if installed, with a built-in pure NumPy
             Random Forest implementation as a zero-dependency fallback.
=============================================================================
"""

import os
import joblib
import pandas as pd
import numpy as np

import sys
# Configure utf-8 output for Windows console resilience
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# ---------------------------------------------------------------------------
# Attempt to import Scikit-Learn; provide zero-dependency fallbacks if needed
# ---------------------------------------------------------------------------
SKLEARN_AVAILABLE = False
try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# Pure Python/NumPy Fallback implementations for educational resilience
def fallback_train_test_split(X, y, test_size=0.2, random_state=42):
    np.random.seed(random_state)
    indices = np.arange(len(X))
    np.random.shuffle(indices)
    split_point = int(len(X) * (1 - test_size))
    train_idx, test_idx = indices[:split_point], indices[split_point:]
    return X.iloc[train_idx].reset_index(drop=True), X.iloc[test_idx].reset_index(drop=True), \
           y.iloc[train_idx].reset_index(drop=True), y.iloc[test_idx].reset_index(drop=True)

def fallback_metrics(y_true, y_pred):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    
    total = len(y_true)
    acc = (tp + tn) / total if total > 0 else 0.0
    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * (prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0
    cm = [[tn, fp], [fn, tp]]
    return acc, prec, rec, f1, cm

# Import pure Python/NumPy Fallback implementations from model_classes
from model_classes import SimpleRandomForestClassifier, SimpleDecisionTree, DecisionTreeNode


# ---------------------------------------------------------------------------
# Main Model Training Pipeline
# ---------------------------------------------------------------------------
def train_battery_fault_model():
    print("=" * 65)
    print("🔋 EV Battery Fault Prediction - Model Training Pipeline")
    print(f"Backend Engine: {'Scikit-Learn' if SKLEARN_AVAILABLE else 'Pure Python/NumPy Fallback'}")
    print("=" * 65)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, "data", "battery_data.csv")
    model_dir = os.path.join(base_dir, "model")
    model_path = os.path.join(model_dir, "battery_model.pkl")

    if not os.path.exists(data_path):
        raise FileNotFoundError(f"Dataset not found at {data_path}. Please check data folder.")

    print(f"\n[Step 1] Loading dataset from: {data_path}")
    df = pd.read_csv(data_path)
    print(f"-> Total records loaded: {len(df)}")
    print(f"-> Features: {list(df.columns[:-1])}")
    print(f"-> Target distribution:\n{df['Fault'].value_counts().to_dict()} (0: Normal, 1: Faulty)")

    feature_cols = ['Voltage', 'Current', 'Temperature', 'SOC', 'SOH']
    X = df[feature_cols]
    y = df['Fault']

    print("\n[Step 2] Splitting data into 80% Training and 20% Testing sets...")
    if SKLEARN_AVAILABLE:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=42, stratify=y
        )
    else:
        X_train, X_test, y_train, y_test = fallback_train_test_split(
            X, y, test_size=0.20, random_state=42
        )

    print(f"-> Training samples: {len(X_train)}")
    print(f"-> Testing samples:  {len(X_test)}")

    print("\n[Step 3] Training Random Forest Classifier...")
    if SKLEARN_AVAILABLE:
        model = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42)
    else:
        model = SimpleRandomForestClassifier(n_estimators=40, max_depth=6, random_state=42)

    model.fit(X_train, y_train)
    print("-> Model training completed successfully!")

    print("\n[Step 4] Evaluating Model Performance on Test Set:")
    y_pred = model.predict(X_test)

    if SKLEARN_AVAILABLE:
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        cm = confusion_matrix(y_test, y_pred).tolist()
    else:
        acc, prec, rec, f1, cm = fallback_metrics(y_test, y_pred)

    print("-" * 45)
    print(f" Accuracy  : {acc * 100:.2f}%")
    print(f" Precision : {prec * 100:.2f}%")
    print(f" Recall    : {rec * 100:.2f}%")
    print(f" F1-Score  : {f1 * 100:.2f}%")
    print("-" * 45)
    print("Confusion Matrix:")
    print("               Predicted Normal  Predicted Fault")
    print(f"Actual Normal        {cm[0][0]:<16}  {cm[0][1]}")
    print(f"Actual Fault         {cm[1][0]:<16}  {cm[1][1]}")
    print("-" * 45)

    importances = dict(zip(feature_cols, model.feature_importances_))
    sorted_importances = dict(sorted(importances.items(), key=lambda item: item[1], reverse=True))
    print("\n[Step 5] Global Feature Importances:")
    for feat, imp in sorted_importances.items():
        bar = "#" * int(imp * 30)
        print(f"  {feat:<12} : {imp*100:5.2f}%  {bar}")

    os.makedirs(model_dir, exist_ok=True)
    payload = {
        'model': model,
        'feature_names': feature_cols,
        'metrics': {
            'accuracy': float(acc),
            'precision': float(prec),
            'recall': float(rec),
            'f1_score': float(f1),
            'confusion_matrix': cm
        },
        'global_feature_importances': sorted_importances
    }

    joblib.dump(payload, model_path)
    print(f"\n[Step 6] Model and metadata saved to:\n  -> {model_path}")
    print("=" * 65)
    return payload

if __name__ == '__main__':
    train_battery_fault_model()
