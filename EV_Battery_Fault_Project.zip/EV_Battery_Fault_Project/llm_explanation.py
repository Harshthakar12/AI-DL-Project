"""
=============================================================================
Project: Explainable EV Battery Fault Prediction Using ML, NLP and LLM
File: llm_explanation.py
Description: Contains:
             1. NLP Bridge: Converts structured numerical telemetry &
                explainability factors into structured descriptive text.
             2. LLM Engine: Uses an LLM (Gemini / OpenAI API) or a reliable
                offline template fallback to generate beginner-friendly,
                human-readable diagnostic explanations.
=============================================================================
"""

import os

def create_nlp_telemetry_prompt(input_dict, prediction_result):
    """
    NLP BRIDGE:
    Converts raw numerical battery telemetry and explainability output
    into a concise textual summary.
    """
    v = input_dict.get('Voltage', 0.0)
    c = input_dict.get('Current', 0.0)
    t = input_dict.get('Temperature', 0.0)
    soc = input_dict.get('SOC', 0.0)
    soh = input_dict.get('SOH', 0.0)

    pred_label = prediction_result.get('prediction_label', 'Normal')
    prob = prediction_result.get('fault_probability', 0.0) * 100

    # Extract top influential factors
    ranked_factors = prediction_result.get('ranked_factors', [])
    top_factors = [
        f"{f['feature']} ({f['influence_level']})"
        for f in ranked_factors if f['influence_level'] in ['High influence', 'Medium influence']
    ]
    if not top_factors and ranked_factors:
        top_factors = [f"{ranked_factors[0]['feature']} (High influence)"]

    top_factors_str = ", ".join(top_factors)

    # Construct the NLP bridge text
    nlp_text = (
        f"Battery Telemetry Report:\n"
        f"- Battery voltage is {v:.2f} V.\n"
        f"- Battery current is {c:.1f} A.\n"
        f"- Battery temperature is {t:.1f}°C.\n"
        f"- Battery State of Charge (SOC) is {soc:.1f}%.\n"
        f"- Battery State of Health (SOH) is {soh:.1f}%.\n\n"
        f"Machine Learning Diagnosis:\n"
        f"- The model predicted: {pred_label.upper()}.\n"
        f"- Fault probability confidence: {prob:.1f}%.\n"
        f"- Key influential factors identified by Explainable AI: {top_factors_str}."
    )
    return nlp_text


def generate_offline_template_explanation(input_dict, prediction_result):
    """
    FALLBACK EXPLANATION GENERATOR:
    100% dependable offline logic when internet or API keys are unavailable.
    Constructs a clear, professional explanation tailored to the detected factors.
    """
    is_faulty = prediction_result.get('prediction', 0) == 1
    ranked = prediction_result.get('ranked_factors', [])
    top_two = [r['feature'] for r in ranked[:2]]
    
    v = input_dict.get('Voltage', 0.0)
    c = input_dict.get('Current', 0.0)
    t = input_dict.get('Temperature', 0.0)
    soc = input_dict.get('SOC', 0.0)
    soh = input_dict.get('SOH', 0.0)

    reasons = []
    if 'Temperature' in top_two:
        if t > 45.0:
            reasons.append(f"the elevated battery temperature of {t:.1f}°C indicates thermal stress")
        else:
            reasons.append("temperature conditions remain within acceptable bounds")
            
    if 'SOH' in top_two:
        if soh < 75.0:
            reasons.append(f"a degraded State of Health at {soh:.1f}% signifies internal cell aging and higher resistance")
        else:
            reasons.append("the cell health is relatively robust")

    if 'Current' in top_two:
        if c > 60.0:
            reasons.append(f"the high current draw of {c:.1f} A places heavy instantaneous electrical load on the pack")
        else:
            reasons.append("the operating current is moderate")

    if 'Voltage' in top_two:
        if v < 3.2:
            reasons.append(f"the low terminal voltage of {v:.2f} V points towards severe deep discharge")
        elif v > 4.25:
            reasons.append(f"the high voltage reading of {v:.2f} V suggests risk of cell overcharging")

    if not reasons:
        reasons.append(f"variations observed primarily in {', '.join(top_two)}")

    reasons_str = "; furthermore, ".join(reasons)

    if is_faulty:
        explanation = (
            f"The battery has been classified as POTENTIALLY FAULTY by the Random Forest model "
            f"(Confidence: {prediction_result.get('fault_probability', 0)*100:.1f}%). "
            f"The prediction was primarily driven by: {reasons_str}. "
            f"Operating under these conditions risks accelerated degradation or thermal safety hazards. "
            f"Immediate physical inspection and BMS diagnostics are recommended."
        )
    else:
        explanation = (
            f"The battery has been classified as NORMAL by the Random Forest model "
            f"(Confidence: {prediction_result.get('normal_probability', 0)*100:.1f}%). "
            f"Operating telemetry for Voltage ({v:.2f} V), Temperature ({t:.1f}°C), and "
            f"State of Health ({soh:.1f}%) remain well within safe operating margins. "
            f"The battery is operating reliably."
        )

    return explanation


def generate_llm_explanation(input_dict, prediction_result, api_key=None, provider="gemini"):
    """
    Main LLM explanation router.
    Attempts live LLM API call if API key is provided, otherwise falls back gracefully.
    """
    # 1. First generate the NLP structured context prompt
    nlp_summary = create_nlp_telemetry_prompt(input_dict, prediction_result)

    # 2. Check for API key from parameter or environment
    gemini_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    openai_key = api_key or os.getenv("OPENAI_API_KEY")

    system_instruction = (
        "You are an AI assistant in an educational EV Battery Diagnostic system. "
        "Your task is ONLY to translate the Machine Learning diagnosis and feature importance factors "
        "into a clear, concise (2-3 sentences) plain-English explanation for an EV driver or technician. "
        "Do NOT invent new diagnoses or contradict the ML prediction. "
        "Explicitly mention the primary influential factors."
    )

    prompt = (
        f"{system_instruction}\n\n"
        f"Input Telemetry & Diagnosis:\n{nlp_summary}\n\n"
        f"Provide the clear, friendly explanation:"
    )

    # 3. Try Gemini if available
    if provider == "gemini" and gemini_key:
        try:
            from google import genai
            client = genai.Client(api_key=gemini_key)
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt
            )
            if response and response.text:
                return {
                    'nlp_context': nlp_summary,
                    'explanation': response.text.strip(),
                    'source': 'LLM (Google Gemini Live API)'
                }
        except Exception as e:
            # If API fails (quota/network), log and seamlessly fall back
            pass

    # 4. Try OpenAI if key is available
    if openai_key and (provider == "openai" or not gemini_key):
        try:
            import urllib.request
            import json
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {openai_key}"
            }
            body = json.dumps({
                "model": "gpt-4o-mini",
                "messages": [
                    {"role": "system", "content": system_instruction},
                    {"role": "user", "content": nlp_summary}
                ],
                "temperature": 0.3,
                "max_tokens": 150
            }).encode('utf-8')
            req = urllib.request.Request("https://api.openai.com/v1/chat/completions", data=body, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                text = result['choices'][0]['message']['content'].strip()
                return {
                    'nlp_context': nlp_summary,
                    'explanation': text,
                    'source': 'LLM (OpenAI Live API)'
                }
        except Exception:
            pass

    # 5. Default Fallback (Offline Template Generator)
    fallback_text = generate_offline_template_explanation(input_dict, prediction_result)
    return {
        'nlp_context': nlp_summary,
        'explanation': fallback_text,
        'source': 'Deterministic Natural-Language Template (Offline Fallback)'
    }
