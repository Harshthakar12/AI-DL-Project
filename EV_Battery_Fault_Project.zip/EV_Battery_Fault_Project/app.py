"""
=============================================================================
Project: Explainable EV Battery Fault Prediction Using ML, NLP and LLM
File: app.py
Description: Streamlit Web Application providing an interactive interface
             for EV battery telemetry input, Random Forest fault diagnosis,
             explainable factor visualization, and natural-language AI summaries.
=============================================================================
"""

import os
import joblib
import pandas as pd
import streamlit as st

# Import project modules
import model_classes
import train_model
from explain import explain_prediction
from llm_explanation import generate_llm_explanation

# Page configuration
st.set_page_config(
    page_title="EV Battery Fault Prediction & Explanation",
    page_icon="🔋",
    layout="wide"
)

# Custom styling for clean UI
st.markdown("""
<style>
    .metric-card {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        border-left: 5px solid #007bff;
        margin-bottom: 10px;
    }
    .status-normal {
        color: #28a745;
        font-size: 26px;
        font-weight: bold;
    }
    .status-fault {
        color: #dc3545;
        font-size: 26px;
        font-weight: bold;
    }
    .disclaimer-box {
        background-color: #fff3cd;
        color: #856404;
        padding: 12px;
        border-radius: 8px;
        border: 1px solid #ffeeba;
        font-size: 13px;
        margin-top: 25px;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_trained_model():
    """Loads the serialized Random Forest model and metadata."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(base_dir, "model", "battery_model.pkl")
    
    if not os.path.exists(model_path):
        return None
    try:
        data = joblib.load(model_path)
        return data
    except Exception as e:
        st.error(f"Error loading model: {e}")
        return None


def main():
    # Header
    st.title("🔋 EV Battery Fault Prediction & Explanation")
    st.caption("A beginner-friendly explainable AI system powered by Random Forest, NLP & LLMs")

    # Load model
    model_pkg = load_trained_model()
    if model_pkg is None:
        st.error("⚠️ Trained model not found! Please run `python train_model.py` first to train and save the model.")
        st.info("You can train the model from the terminal using:\n```bash\npython train_model.py\n```")
        return

    model = model_pkg['model']
    feature_names = model_pkg.get('feature_names', ['Voltage', 'Current', 'Temperature', 'SOC', 'SOH'])
    metrics = model_pkg.get('metrics', {})

    # Sidebar: Quick Presets & Configurations
    with st.sidebar:
        st.header("⚡ Quick Demo Presets")
        st.write("Click a preset to quickly load test battery parameters for viva demonstration:")

        preset = st.radio(
            "Select Scenario:",
            [
                "Custom Input",
                "Normal Operating Cell",
                "Thermal Overheat Fault",
                "High Current Stress Fault",
                "Severe SOH Degradation Fault",
                "Under-Voltage Discharge Fault"
            ]
        )

        preset_values = {
            "Normal Operating Cell": {"v": 3.70, "c": 22.0, "t": 28.5, "soc": 80.0, "soh": 95.0},
            "Thermal Overheat Fault": {"v": 3.65, "c": 55.0, "t": 58.0, "soc": 75.0, "soh": 85.0},
            "High Current Stress Fault": {"v": 3.25, "c": 85.0, "t": 48.0, "soc": 65.0, "soh": 82.0},
            "Severe SOH Degradation Fault": {"v": 3.40, "c": 40.0, "t": 42.0, "soc": 45.0, "soh": 62.0},
            "Under-Voltage Discharge Fault": {"v": 2.90, "c": 30.0, "t": 32.0, "soc": 12.0, "soh": 80.0},
        }

        st.divider()
        st.header("🤖 LLM Configuration (Optional)")
        st.caption("Works 100% offline using dynamic templates! Enter a key only if you wish to test live LLM calls.")
        provider = st.selectbox("LLM Provider", ["gemini", "openai"])
        api_key = st.text_input(
            f"{provider.capitalize()} API Key",
            type="password",
            help="Leave blank to use the dependable built-in offline explanation generator."
        )

        st.divider()
        st.header("📊 Model Metrics")
        if metrics:
            st.metric("Model Accuracy", f"{metrics.get('accuracy', 0)*100:.1f}%")
            st.metric("F1-Score", f"{metrics.get('f1_score', 0)*100:.1f}%")

    # Determine default values based on chosen preset
    defaults = preset_values.get(preset, {"v": 3.70, "c": 25.0, "t": 30.0, "soc": 70.0, "soh": 90.0})

    # Main Input Section
    st.subheader("1. Enter EV Battery Parameters")
    st.write("Provide real-time telemetry from the battery management system (BMS):")

    col1, col2, col3 = st.columns(3)
    with col1:
        voltage = st.number_input("Voltage (V)", min_value=1.5, max_value=5.0, value=float(defaults["v"]), step=0.05,
                                  help="Cell terminal voltage. Normal range: ~3.4V to 4.2V")
        current = st.number_input("Current (A)", min_value=0.0, max_value=150.0, value=float(defaults["c"]), step=1.0,
                                  help="Discharge / charge current. Normal: 10A to 45A")

    with col2:
        temperature = st.number_input("Temperature (°C)", min_value=0.0, max_value=100.0, value=float(defaults["t"]), step=0.5,
                                      help="Cell temperature. Safe range: 20°C to 40°C")
        soc = st.number_input("State of Charge - SOC (%)", min_value=0.0, max_value=100.0, value=float(defaults["soc"]), step=1.0,
                              help="Available battery capacity level in percentage")

    with col3:
        soh = st.number_input("State of Health - SOH (%)", min_value=10.0, max_value=100.0, value=float(defaults["soh"]), step=1.0,
                              help="Remaining battery health capacity relative to new cell")

    # Input validation check
    validation_error = None
    if voltage < 2.0 or voltage > 4.5:
        st.warning("⚠️ Notice: Typical Li-ion operational voltage spans between 2.8V and 4.3V.")
    if temperature > 60.0:
        st.warning("⚠️ Critical: Temperature exceeds 60°C; severe risk of thermal runaway.")

    predict_button = st.button("🔍 Predict Battery Fault", type="primary", use_container_width=True)

    if predict_button:
        # Prepare input dictionary
        input_data = {
            'Voltage': float(voltage),
            'Current': float(current),
            'Temperature': float(temperature),
            'SOC': float(soc),
            'SOH': float(soh)
        }

        # Step 1 & 2: Predict and Explain
        with st.spinner("Analyzing battery state and running explainability module..."):
            explanation_data = explain_prediction(model, input_data, feature_names)

        is_fault = explanation_data['prediction'] == 1
        fault_prob = explanation_data['fault_probability'] * 100
        norm_prob = explanation_data['normal_probability'] * 100

        st.divider()

        # Section 1 & 2: Prediction and Confidence
        res_col1, res_col2 = st.columns([1, 1])

        with res_col1:
            st.subheader("2. Prediction Result")
            if is_fault:
                st.markdown('<div class="status-fault">🔴 POTENTIAL FAULT DETECTED</div>', unsafe_allow_html=True)
                st.error("The ML model indicates an abnormal battery state requiring inspection.")
            else:
                st.markdown('<div class="status-normal">🟢 NORMAL OPERATING CONDITION</div>', unsafe_allow_html=True)
                st.success("The battery parameters are within safe operational boundaries.")

        with res_col2:
            st.subheader("Model Confidence")
            st.write(f"**Fault Probability:** `{fault_prob:.1f}%`")
            st.write(f"**Normal Probability:** `{norm_prob:.1f}%`")
            st.progress(int(fault_prob), text=f"Fault Probability: {fault_prob:.1f}%")

        st.divider()

        # Section 3: Explainability & Feature Importance
        st.subheader("3. Explainability: Contributing Factors")
        st.write("Which parameters influenced the Random Forest decision most for this specific reading?")

        ranked_factors = explanation_data['ranked_factors']
        chart_df = pd.DataFrame([
            {"Parameter": r['feature'], "Contribution (%)": r['importance_percent']}
            for r in ranked_factors
        ]).set_index("Parameter")

        col_chart, col_table = st.columns([1.2, 1])

        with col_chart:
            st.bar_chart(chart_df, horizontal=True)

        with col_table:
            st.write("**Influence Breakdown:**")
            for factor in ranked_factors:
                badge = "🔴" if factor['influence_level'] == "High influence" else ("🟡" if factor['influence_level'] == "Medium influence" else "⚪")
                st.markdown(f"{badge} **{factor['feature']}**: `{factor['value']}` → *{factor['influence_level']}* ({factor['importance_percent']}%)")

        st.divider()

        # Section 4: NLP Bridge & AI Explanation
        st.subheader("4. Natural Language Explanation (LLM Module)")

        with st.spinner("Synthesizing diagnostic explanation..."):
            llm_result = generate_llm_explanation(
                input_data,
                explanation_data,
                api_key=api_key if api_key.strip() else None,
                provider=provider
            )

        # Show NLP Bridge (Collapsible for viva evaluation)
        with st.expander("📝 View NLP Bridge Text (Input sent to LLM)", expanded=False):
            st.code(llm_result['nlp_context'], language="text")
            st.caption("NLP acts as the bridge converting tabular values and explainability vectors into descriptive language.")

        # Show LLM Explanation
        st.info(f"💡 **Explanation ({llm_result['source']}):**\n\n{llm_result['explanation']}")

    # Footer Disclaimer
    st.markdown("""
    <div class="disclaimer-box">
        <strong>⚠️ Important Educational Disclaimer:</strong><br>
        This software is an academic educational prototype developed for demonstration and viva presentation purposes.
        The dataset and diagnostic thresholds do not represent certified manufacturer safety limits and must NOT be used
        for real-world electric vehicle battery control or mission-critical safety diagnosis.
    </div>
    """, unsafe_allow_html=True)


if __name__ == '__main__':
    main()
